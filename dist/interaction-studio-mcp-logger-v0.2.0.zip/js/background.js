importScripts("sdk-config.js");

console.log("Background js loaded..");

const CONFIG = {
  RECORD_TIMER: 1.5 * 1000,
};

const delay = (ms) => new Promise((res) => setTimeout(res, ms));

/** Serialize storage writes so concurrent events cannot overwrite each other. */
let storageWriteQueue = Promise.resolve();

/** requestId -> pending event data captured in onBeforeRequest */
const pendingRequests = new Map();

function isEvergageEventRequest(url) {
  return url.indexOf("evergage.com/api2/event/") > -1;
}

function isDataCloudEventRequest(url) {
  return (
    url.indexOf("c360a.salesforce.com/web/events/") > -1 ||
    url.indexOf(".c360a.salesforce.com/web/events/") > -1
  );
}

function isTrackedEventRequest(request) {
  return (
    (request.method === "GET" || request.method === "POST") &&
    typeof request.url === "string" &&
    (isEvergageEventRequest(request.url) ||
      isDataCloudEventRequest(request.url))
  );
}

function decodeBase64Utf8(encodedString) {
  const binary = atob(encodedString);
  const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

function parseEventValue(eventValue) {
  if (eventValue == null) {
    throw new Error("Missing event value");
  }
  // Raw JSON
  try {
    return JSON.parse(eventValue);
  } catch (_) {
    // fall through
  }
  // Base64 JSON (Data Cloud / some Evergage POST bodies)
  try {
    return JSON.parse(decodeBase64Utf8(eventValue));
  } catch (_) {
    // fall through
  }
  // URL-encoded base64
  try {
    return JSON.parse(decodeBase64Utf8(decodeURIComponent(eventValue)));
  } catch (_) {
    throw new Error("Unable to parse event payload value");
  }
}

function extractPayload(request) {
  if (request.method === "GET") {
    const url = new URL(request.url);
    // searchParams.get already URL-decodes the value
    const encodedString = url.searchParams.get("event");
    if (!encodedString) {
      throw new Error("Missing event query parameter");
    }
    return parseEventValue(encodedString);
  }

  const formEvent = request.requestBody?.formData?.event?.[0];
  if (formEvent) {
    return parseEventValue(formEvent);
  }

  const rawBytes = request.requestBody?.raw?.[0]?.bytes;
  if (rawBytes) {
    const rawText = new TextDecoder().decode(new Uint8Array(rawBytes));
    try {
      return JSON.parse(rawText);
    } catch (_) {
      const params = new URLSearchParams(rawText);
      const eventValue = params.get("event");
      if (!eventValue) {
        throw new Error("Missing event field in POST body");
      }
      return parseEventValue(eventValue);
    }
  }

  throw new Error("Unable to extract event payload from request");
}

function getWebsiteName(request) {
  if (request.initiator) {
    try {
      return new URL(request.initiator).hostname;
    } catch (_) {
      // fall through
    }
  }
  if (request.documentUrl) {
    try {
      return new URL(request.documentUrl).hostname;
    } catch (_) {
      // fall through
    }
  }
  return "unknown";
}

function buildHostKey(request, websiteName) {
  const url = new URL(request.url);

  if (isDataCloudEventRequest(request.url)) {
    const pathParts = url.pathname.split("/").filter(Boolean);
    // /web/events/<app-id>
    const appId = pathParts[pathParts.length - 1] || "unknown";
    const shortId = appId.length > 12 ? appId.slice(0, 8) : appId;
    return websiteName + " | Data Cloud (app: " + shortId + ")";
  }

  const evergageHost = url.hostname.split(".")[0];
  const pathParts = url.pathname.split("/").filter(Boolean);
  const datasetName = pathParts[pathParts.length - 1] || "unknown";
  return websiteName + " | " + evergageHost + " (ds: " + datasetName + ")";
}

function extractEventTime(payload) {
  if (!payload || typeof payload !== "object") return null;

  const normalizeEpoch = (value) => {
    if (typeof value !== "number" || !Number.isFinite(value)) return null;
    // Seconds vs milliseconds heuristic
    if (value > 0 && value < 1e11) return value * 1000;
    return value;
  };

  if (Array.isArray(payload.events) && payload.events.length) {
    const times = payload.events
      .map((e) => {
        if (!e) return null;
        if (typeof e.dateTime === "string") {
          const parsed = Date.parse(e.dateTime);
          return Number.isFinite(parsed) ? parsed : null;
        }
        return normalizeEpoch(e.dateTime) || normalizeEpoch(e.time);
      })
      .filter((t) => Number.isFinite(t));
    if (times.length) return Math.max.apply(null, times);
  }

  const sourceTime = normalizeEpoch(payload.source && payload.source.time);
  if (sourceTime != null) return sourceTime;

  const topTime = normalizeEpoch(payload.time);
  if (topTime != null) return topTime;

  if (typeof payload.dateTime === "string") {
    const parsed = Date.parse(payload.dateTime);
    if (Number.isFinite(parsed)) return parsed;
  }

  return null;
}

function saveEvent(request, payload, statusCode) {
  const websiteName = getWebsiteName(request);
  const hostName = buildHostKey(request, websiteName);
  const capturedAt = Date.now();
  const eventTime = extractEventTime(payload) || capturedAt;
  const epocheDate = String(eventTime) + "-" + String(capturedAt);

  const isPayload = {};
  isPayload[epocheDate] = {
    url: request.url,
    payload: payload,
    datetime: capturedAt,
    eventTime: eventTime,
    website: websiteName,
    statusCode: statusCode,
    sdk: isDataCloudEventRequest(request.url) ? "data-cloud" : "evergage",
  };

  storageWriteQueue = storageWriteQueue
    .then(
      () =>
        new Promise((resolve) => {
          // Read and write only this site's list: rewriting all of storage on
          // every event got slower as the log (and saved SDK code) grew.
          chrome.storage.local.get(hostName, function (stored) {
            const list = Array.isArray(stored[hostName]) ? stored[hostName] : [];
            list.push(isPayload);
            chrome.storage.local.set({ [hostName]: list }, async function () {
              try {
                chrome.action.setIcon({
                  path: "../images/activeImg/cloud-48.png",
                });
                await delay(CONFIG.RECORD_TIMER);
                chrome.action.setIcon({ path: "../images/cloud/cloud-48.png" });
              } catch (e) {
                console.warn("Failed to update action icon", e);
              }
              resolve();
            });
          });
        })
    )
    .catch((e) => {
      console.error("Failed to persist event", e);
    });
}

function finalizeRequest(requestId, statusCode) {
  const pending = pendingRequests.get(requestId);
  if (!pending) {
    return;
  }
  pendingRequests.delete(requestId);
  saveEvent(pending.request, pending.payload, statusCode);
}

chrome.webRequest.onBeforeRequest.addListener(
  function (request) {
    if (!isTrackedEventRequest(request)) {
      return;
    }
    try {
      const payload = extractPayload(request);
      pendingRequests.set(request.requestId, {
        request: {
          url: request.url,
          method: request.method,
          initiator: request.initiator,
          documentUrl: request.documentUrl,
        },
        payload: payload,
      });
    } catch (e) {
      console.error("Failed to parse tracked event request", request.url, e);
    }
  },
  { urls: ["<all_urls>"] },
  ["requestBody"]
);

chrome.webRequest.onCompleted.addListener(
  function (request) {
    if (!isTrackedEventRequest(request)) {
      return;
    }
    finalizeRequest(request.requestId, request.statusCode);
  },
  { urls: ["<all_urls>"] }
);

chrome.webRequest.onErrorOccurred.addListener(
  function (request) {
    if (!isTrackedEventRequest(request)) {
      return;
    }
    // Still record the attempt; statusCode null marks transport failure in UI.
    finalizeRequest(request.requestId, null);
  },
  { urls: ["<all_urls>"] }
);

/* ---------------- SDK Force URL + Local Edit ---------------- */

/**
 * Redirect to an http URL that is not on localhost: fetch it now and keep
 * the code, so the redirect can serve it as a data: URL (see sdk-config.js).
 */
async function withFetchedSdk(settings) {
  const url = String(settings.forceSdk.url || "").trim();
  if (!settings.forceSdk.enabled || !needsFetchedSdk(url)) {
    settings.forceSdk.fetched = null;
    return settings;
  }
  const normalized = new URL(url).toString();
  const fetched = { url: normalized, code: "", bytes: 0, at: Date.now(), error: "" };
  try {
    const res = await fetch(normalized, { cache: "no-store" });
    if (!res.ok) throw new Error("HTTP " + res.status + " fetching " + normalized);
    const code = await res.text();
    if (code.length > MAX_FETCHED_SDK_CHARS) {
      throw new Error(
        "The file is " + Math.round(code.length / 1024) + " KB, too large to serve this way (limit " +
          Math.round(MAX_FETCHED_SDK_CHARS / 1024) + " KB)."
      );
    }
    fetched.code = code;
    fetched.bytes = code.length;
  } catch (err) {
    fetched.error = String(err && err.message ? err.message : err);
  }
  settings.forceSdk.fetched = fetched;
  return settings;
}

/** What SDK Tools does on this page, for the content script's console notes. */
function pageSdkStatus(settings, hostname) {
  const local = settings.localEdit;
  const force = settings.forceSdk;
  const mode = local.enabled && local.edited ? "edit" : force.enabled && force.url ? "redirect" : "off";
  if (mode === "off") return { mode: "off" };
  // On, but not here: the content script notes it if the page loads the SDK.
  if (!siteMatches(settings.sites, hostname)) return { mode: "off", unlisted: mode };
  const injectWhenMissing = settings.injectWhenMissing !== false;
  if (mode === "edit") {
    return {
      mode,
      injectWhenMissing,
      servedBy: editServedByRedirect(settings) ? "redirect" : "inject",
      id: sdkFingerprint(local.edited),
      savedAt: local.savedAt || null,
    };
  }
  const fetched = needsFetchedSdk(force.url) ? force.fetched : null;
  return {
    mode,
    injectWhenMissing,
    url: force.url,
    servedBy: fetched ? "fetched" : "redirect",
    fetchError: fetched && fetched.error ? fetched.error : "",
    id: fetched && fetched.code ? sdkFingerprint(fetched.code) : "",
  };
}

/* Page diagnostics: what SDK Tools did on recent page loads, for Feedback. */
const MCP_DIAG_KEY = "__mcp_diag__";
const MAX_DIAG_REPORTS = 15;
let diagWrite = Promise.resolve();

function saveDiagReport(report, tab) {
  // Serialize writes: a page can send several updates in quick succession.
  diagWrite = diagWrite.then(async () => {
    const items = await chrome.storage.local.get(MCP_DIAG_KEY);
    const list = Array.isArray(items[MCP_DIAG_KEY]) ? items[MCP_DIAG_KEY] : [];
    const entry = { ...report, tabId: tab ? tab.id : null, receivedAt: Date.now() };
    const i = list.findIndex((r) => r.reportId === report.reportId);
    if (i >= 0) list[i] = entry;
    else list.unshift(entry);
    await chrome.storage.local.set({ [MCP_DIAG_KEY]: list.slice(0, MAX_DIAG_REPORTS) });
  }).catch((e) => console.warn("Could not save page diagnostics", e));
  return diagWrite;
}

async function injectLocalSdk(tabId, pageUrl) {
  const settings = await readMcpSettings();
  let hostname = "";
  try {
    hostname = new URL(pageUrl || "").hostname;
  } catch (_) {}
  const status = pageSdkStatus(settings, hostname);
  if (status.mode !== "edit" || status.servedBy !== "inject") {
    // Off, not a listed site, Redirect, or the SDK request is redirected to
    // the edited code.
    return { injected: false, status };
  }

  const code = withSdkBanner(settings.localEdit.edited, {
    mode: "edit",
    savedAt: settings.localEdit.savedAt,
  });
  await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: (sdkCode, meta) => {
      try {
        if (window.__MCP_LOCAL_SDK_INJECTED__) {
          return;
        }
        window.__MCP_LOCAL_SDK_INJECTED__ = true;
        window.__MCP_LOCAL_SDK_META__ = meta;
        // eval is subject to the page CSP; the CSP header is removed on the
        // listed sites while Edit is on (see buildSdkDnrRules).
        (0, eval)(sdkCode);
      } catch (err) {
        console.error("[MCP Logger] Local Edit SDK injection failed", err);
        window.__MCP_LOCAL_SDK_ERROR__ = String(err && err.message ? err.message : err);
      }
    },
    args: [
      code,
      {
        fileName: settings.localEdit.fileName || "local-edit.js",
        sourceUrl: settings.localEdit.sourceUrl || "",
        updatedAt: settings.localEdit.updatedAt || null,
      },
    ],
  });

  return { injected: true, status };
}

/**
 * The page on a listed site has not loaded the SDK by DOMContentLoaded:
 * inject it (the replacement URL as a script tag, or the edited or fetched
 * code), and block the page's own SDK in this tab so a late tag does not run
 * a second copy.
 */
async function injectMissingSdk(tabId, frameId, pageUrl) {
  const settings = await readMcpSettings();
  let hostname = "";
  try {
    hostname = new URL(pageUrl || "").hostname;
  } catch (_) {}
  const status = pageSdkStatus(settings, hostname);
  if (status.mode === "off" || !status.injectWhenMissing || status.servedBy === "inject") {
    return { injected: false, status };
  }

  let src = "";
  let code = "";
  if (status.mode === "edit") {
    code = withSdkBanner(settings.localEdit.edited, { mode: "edit", savedAt: settings.localEdit.savedAt });
  } else if (status.servedBy === "fetched") {
    const fetched = settings.forceSdk.fetched;
    if (!fetched || !fetched.code) return { injected: false, status, error: status.fetchError || "not fetched" };
    code = withSdkBanner(fetched.code, { mode: "redirect", url: status.url, savedAt: fetched.at });
  } else {
    src = new URL(String(status.url).trim()).toString();
  }

  await updateTabBlock(tabId, true);

  const [result] = await chrome.scripting.executeScript({
    target: { tabId, frameIds: [frameId || 0] },
    world: "MAIN",
    injectImmediately: true,
    func: (scriptSrc, sdkCode) => {
      if (window.__MCP_SDK_TOOLS_INJECTED__) return { skipped: true };
      window.__MCP_SDK_TOOLS_INJECTED__ = true;
      if (scriptSrc) {
        const s = document.createElement("script");
        s.src = scriptSrc;
        s.setAttribute("data-mcp-sdk-tools-injected", "");
        // Keep the order of a parser-inserted tag relative to later injections.
        s.async = false;
        (document.head || document.documentElement).appendChild(s);
        return { ok: true };
      }
      try {
        // eval is subject to the page CSP; the CSP header is removed on the
        // listed sites while a tool is on (see buildSdkDnrRules).
        (0, eval)(sdkCode);
        return { ok: true };
      } catch (err) {
        console.error("[MCP Logger] SDK Tools could not run the injected SDK", err);
        return { error: String(err && err.message ? err.message : err) };
      }
    },
    args: [src, code],
  });
  const out = (result && result.result) || {};
  return { injected: !!out.ok, skipped: !!out.skipped, error: out.error || "", src, status };
}

let tabBlockWrite = Promise.resolve();

/** Add a tab to, or take it off, the per-tab SDK block. Writes run in order. */
function updateTabBlock(tabId, blocked) {
  const run = tabBlockWrite.then(async () => {
    const current = await chrome.declarativeNetRequest.getSessionRules();
    const rule = current.find((r) => isTabBlockRuleId(r.id));
    const tabs = new Set((rule && rule.condition.tabIds) || []);
    if (blocked === tabs.has(tabId)) return;
    if (blocked) tabs.add(tabId);
    else tabs.delete(tabId);
    await chrome.declarativeNetRequest.updateSessionRules(buildTabBlockRules([...tabs]));
  });
  tabBlockWrite = run.catch(() => {});
  return run;
}

function clearTabBlockRules(tabId) {
  if (typeof tabId !== "number" || tabId < 0) return Promise.resolve();
  return updateTabBlock(tabId, false).catch((e) => console.warn("Could not clear the tab SDK block", e));
}

// A new document in the tab: the previous page's injection no longer applies.
// onBeforeRequest for the main frame fires before the new page can request
// the SDK.
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    clearTabBlockRules(details.tabId);
  },
  { urls: ["<all_urls>"], types: ["main_frame"] }
);
chrome.tabs.onRemoved.addListener((tabId) => clearTabBlockRules(tabId));

/**
 * Switch Redirect and Edit off (the edited SDK, URL and sites are kept), then
 * optionally reload open tabs on the listed sites so they get the real SDK.
 */
async function stopSdkTools(reload) {
  const current = await readMcpSettings();
  const sites = current.sites;
  current.forceSdk.enabled = false;
  current.localEdit.enabled = false;
  const settings = await writeMcpSettings(current);
  await syncSdkDnrRules(settings);
  let reloaded = 0;
  if (reload && sites.length) {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      let hostname = "";
      try {
        const url = new URL(tab.url || "");
        if (url.protocol === "http:" || url.protocol === "https:") hostname = url.hostname;
      } catch (_) {}
      if (!hostname || !siteMatches(sites, hostname)) continue;
      try {
        // Bypass the cache so the edited or redirected SDK is not reused.
        await chrome.tabs.reload(tab.id, { bypassCache: true });
        reloaded++;
      } catch (_) {}
    }
  }
  return { settings, reloaded };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const type = message && message.type;

  if (type === "MCP_GET_SETTINGS") {
    readMcpSettings().then((settings) => sendResponse({ ok: true, settings }));
    return true;
  }

  if (type === "MCP_SAVE_SETTINGS" || type === "MCP_REFETCH_SDK") {
    const next =
      type === "MCP_SAVE_SETTINGS" ? Promise.resolve(message.settings) : readMcpSettings();
    next
      .then((settings) => {
        const merged = mergeSettings(settings);
        if (type === "MCP_SAVE_SETTINGS") merged.localEdit.savedAt = Date.now();
        return withFetchedSdk(merged);
      })
      .then((settings) => writeMcpSettings(settings))
      .then((settings) => syncSdkDnrRules(settings).then(() => settings))
      .then((settings) => sendResponse({ ok: true, settings }))
      .catch((err) =>
        sendResponse({ ok: false, error: String(err && err.message ? err.message : err) })
      );
    return true;
  }

  if (type === "MCP_PAGE_DIAG") {
    const report = message.report && typeof message.report === "object" ? message.report : null;
    if (!report || !report.reportId) return false;
    saveDiagReport(report, sender.tab).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (type === "MCP_STOP_SDK_TOOLS") {
    stopSdkTools(!!message.reload)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) =>
        sendResponse({ ok: false, error: String(err && err.message ? err.message : err) })
      );
    return true;
  }

  if (type === "MCP_FETCH_SDK") {
    const url = String(message.url || "").trim();
    fetch(url)
      .then(async (res) => {
        if (!res.ok) {
          throw new Error("HTTP " + res.status + " fetching SDK");
        }
        const text = await res.text();
        let fileName = "sdk.js";
        try {
          const path = new URL(url).pathname;
          fileName = path.split("/").pop() || fileName;
        } catch (_) {}
        sendResponse({ ok: true, text, fileName, contentType: res.headers.get("content-type") });
      })
      .catch((err) =>
        sendResponse({ ok: false, error: String(err && err.message ? err.message : err) })
      );
    return true;
  }

  if (type === "MCP_INJECT_LOCAL_SDK") {
    const tabId = message.tabId || (sender.tab && sender.tab.id);
    if (!tabId) {
      sendResponse({ ok: false, error: "No tab id" });
      return false;
    }
    // From the content script, sender.url is the page being loaded.
    const pageUrl = message.url || sender.url || (sender.tab && sender.tab.url) || "";
    injectLocalSdk(tabId, pageUrl)
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) =>
        sendResponse({ ok: false, error: String(err && err.message ? err.message : err) })
      );
    return true;
  }

  if (type === "MCP_INJECT_MISSING_SDK") {
    const tabId = sender.tab && sender.tab.id;
    if (!tabId) {
      sendResponse({ ok: false, error: "No tab id" });
      return false;
    }
    injectMissingSdk(tabId, sender.frameId, sender.url || sender.tab.url || "")
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((err) =>
        sendResponse({ ok: false, error: String(err && err.message ? err.message : err) })
      );
    return true;
  }

  if (type === "MCP_CLEAR_EVENTS_KEEP_SETTINGS") {
    readMcpSettings().then((settings) => {
      chrome.storage.local.clear(() => {
        chrome.storage.local.set({ [MCP_SETTINGS_KEY]: settings }, () => {
          syncSdkDnrRules(settings).finally(() => sendResponse({ ok: true }));
        });
      });
    });
    return true;
  }

  return false;
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes[MCP_SETTINGS_KEY]) return;
  const settings = mergeSettings(changes[MCP_SETTINGS_KEY].newValue);
  syncSdkDnrRules(settings).catch((e) => console.error(e));
});

readMcpSettings()
  .then((settings) => syncSdkDnrRules(settings))
  .catch((e) => console.error("Initial SDK DNR sync failed", e));

(function () {
  const els = {
    forceEnabled: document.getElementById("forceEnabled"),
    forceUrl: document.getElementById("forceUrl"),
    localEnabled: document.getElementById("localEnabled"),
    sdkSourceUrl: document.getElementById("sdkSourceUrl"),
    sdkEditor: createSdkEditor(document.getElementById("sdkEditor")),
    metaErrors: document.getElementById("metaErrors"),
    statusLine: document.getElementById("statusLine"),
    metaFile: document.getElementById("metaFile"),
    metaChars: document.getElementById("metaChars"),
    metaUpdated: document.getElementById("metaUpdated"),
    metaDirtyEdit: document.getElementById("metaDirtyEdit"),
    diffPanel: document.getElementById("diffPanel"),
    diffBody: document.getElementById("diffBody"),
    diffStats: document.getElementById("diffStats"),
    fileInput: document.getElementById("fileInput"),
    dirtyBadge: document.getElementById("dirtyBadge"),
    editEmpty: document.getElementById("editEmpty"),
    panelOff: document.getElementById("PanelOff"),
    panelRedirect: document.getElementById("PanelRedirect"),
    panelEdit: document.getElementById("PanelEdit"),
    modeButtons: document.querySelectorAll(".st-mode [data-mode]"),
    modeHint: document.getElementById("modeHint"),
    stepEdit: document.getElementById("StepEdit"),
    stepUse: document.getElementById("StepUse"),
    sitesInput: document.getElementById("sitesInput"),
    injectWhenMissing: document.getElementById("injectWhenMissing"),
    openUrl: document.getElementById("openUrl"),
    openTabHosts: document.getElementById("openTabHosts"),
    openTabHostList: document.getElementById("openTabHostList"),
    forceFetchRow: document.getElementById("forceFetchRow"),
    forceFetchStatus: document.getElementById("forceFetchStatus"),
  };

  let originalText = "";
  let loadedFileName = "";
  let loadedSourceUrl = "";
  let updatedAt = null;
  let savedSnapshot = "";
  let activeMode = "redirect";
  let lastFetched = null;

  function setStatus(message, kind) {
    els.statusLine.textContent = message || "Ready.";
    els.statusLine.className =
      "st-footer-status" + (kind ? " " + kind : "");
  }

  function sendMessage(payload) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(payload, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(response || {});
      });
    });
  }

  function collectSettings() {
    return {
      sites: parseSiteList(els.sitesInput.value),
      injectWhenMissing: !!els.injectWhenMissing.checked,
      forceSdk: {
        enabled: !!els.forceEnabled.checked,
        url: els.forceUrl.value.trim(),
      },
      localEdit: {
        enabled: !!els.localEnabled.checked,
        sourceUrl: loadedSourceUrl || els.sdkSourceUrl.value.trim(),
        fileName: loadedFileName || "",
        original: originalText || "",
        edited: els.sdkEditor.value || "",
        updatedAt: updatedAt,
        openUrl: els.openUrl.value.trim(),
      },
    };
  }

  function snapshotOf(settings) {
    return JSON.stringify({
      sites: settings.sites,
      injectWhenMissing: settings.injectWhenMissing,
      forceSdk: settings.forceSdk,
      localEdit: {
        enabled: settings.localEdit.enabled,
        sourceUrl: settings.localEdit.sourceUrl,
        fileName: settings.localEdit.fileName,
        // Persist editor contents with settings so reload restores draft
        original: settings.localEdit.original,
        edited: settings.localEdit.edited,
        updatedAt: settings.localEdit.updatedAt,
        openUrl: settings.localEdit.openUrl,
      },
    });
  }

  function hasSdkLoaded() {
    return !!(originalText || els.sdkEditor.value);
  }

  function updateDirtyBadge() {
    const dirty = snapshotOf(collectSettings()) !== savedSnapshot;
    els.dirtyBadge.classList.toggle("visible", dirty);
  }


  function updateEditChrome() {
    const loaded = hasSdkLoaded();
    els.editEmpty.style.display = loaded ? "none" : "block";
    els.stepEdit.classList.toggle("is-disabled", !loaded);
    els.stepUse.classList.toggle("is-disabled", !loaded);

    [
      "BtnInjectOpen",
      "BtnCompare",
      "BtnDownloadEdited",
      "BtnResetEdited",
    ].forEach((id) => {
      const btn = document.getElementById(id);
      if (btn) btn.disabled = !loaded;
    });

    els.metaFile.textContent = "Source: " + (loadedFileName || "none");

    const len = els.sdkEditor.value.length;
    const originalLen = originalText.length;
    els.metaChars.textContent = loaded
      ? "Original size: " +
        originalLen.toLocaleString() +
        " · Edited size: " +
        len.toLocaleString() +
        " · id " +
        sdkFingerprint(els.sdkEditor.value)
      : "";

    els.metaUpdated.textContent = updatedAt
      ? "Last loaded: " + new Date(updatedAt).toLocaleString()
      : "";

    if (!loaded) {
      els.metaDirtyEdit.textContent = "";
    } else if (!originalText) {
      els.metaDirtyEdit.textContent = "Edited SDK has changes";
    } else if (els.sdkEditor.value === originalText) {
      els.metaDirtyEdit.textContent = "No edits";
    } else {
      els.metaDirtyEdit.textContent = "Edited SDK has changes";
    }

    updateDirtyBadge();
  }

  const MODE_HINTS = {
    off: "Nothing is changed. Every site loads the SDK normally.",
    redirect: "SDK requests from the sites below load your replacement URL instead, and pages without the SDK get it injected.",
    edit: "On the sites below, your edited copy runs in place of the SDK, and pages without the SDK get it injected.",
  };

  /**
   * One control for both tools: they cannot both be on, because Edit blocks
   * the SDK request that Redirect would replace.
   */
  function setMode(mode) {
    activeMode = mode === "edit" || mode === "redirect" ? mode : "off";
    els.forceEnabled.checked = activeMode === "redirect";
    els.localEnabled.checked = activeMode === "edit";
    els.modeButtons.forEach((btn) =>
      btn.setAttribute("aria-checked", String(btn.dataset.mode === activeMode))
    );
    els.modeHint.textContent = MODE_HINTS[activeMode];
    els.panelOff.hidden = activeMode !== "off";
    els.panelRedirect.hidden = activeMode !== "redirect";
    els.panelEdit.hidden = activeMode !== "edit";
    updateForceUrlWarning();
    updateDirtyBadge();
  }

  function modeOf(settings) {
    if (settings.localEdit.enabled) return "edit";
    if (settings.forceSdk.enabled) return "redirect";
    return "off";
  }

  function applySettings(settings) {
    const s = mergeSettings(settings);
    lastFetched = s.forceSdk.fetched || null;
    els.sitesInput.value = s.sites.join(", ");
    els.injectWhenMissing.checked = s.injectWhenMissing;
    els.openUrl.value = s.localEdit.openUrl || els.openUrl.value || "";
    els.forceEnabled.checked = !!s.forceSdk.enabled;
    els.forceUrl.value = s.forceSdk.url || "";
    els.localEnabled.checked = !!s.localEdit.enabled;
    els.sdkSourceUrl.value = s.localEdit.sourceUrl || "";
    originalText = s.localEdit.original || "";
    els.sdkEditor.value = s.localEdit.edited || s.localEdit.original || "";
    loadedFileName = s.localEdit.fileName || "";
    loadedSourceUrl = s.localEdit.sourceUrl || "";
    updatedAt = s.localEdit.updatedAt || null;
    savedSnapshot = snapshotOf(collectSettings());
    setMode(modeOf(s));
    // Shown while a saved tool is running, whatever the draft says.
    document.getElementById("BtnStop").hidden = modeOf(s) === "off";
    updateEditChrome();
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function describeError(err) {
    return "line " + err.line + ": " + err.text;
  }

  function renderSyntaxErrors(errors) {
    const first = errors[0];
    els.metaErrors.hidden = !first;
    if (!first) return;
    els.metaErrors.textContent =
      (errors.length === 1 ? "Syntax error on " : errors.length + " syntax errors, first on ") +
      describeError(first);
    els.metaErrors.title = "Go to line " + first.line;
  }

  /** A syntax error stops the whole SDK from running, so ask first. */
  function confirmNoSyntaxErrors() {
    const first = els.sdkEditor.errors()[0];
    if (!first) return true;
    return window.confirm(
      "The edited SDK has a syntax error (" +
        describeError(first) +
        "). The browser will not run any of it, so the page gets no SDK. Use it anyway?"
    );
  }

  async function saveSettings() {
    const settings = collectSettings();
    if (settings.localEdit.enabled && !confirmNoSyntaxErrors()) return;

    if ((settings.forceSdk.enabled || settings.localEdit.enabled) && !settings.sites.length) {
      setStatus("Add at least one site under Sites (or * for every site).", "err");
      els.sitesInput.focus();
      return;
    }

    if (settings.forceSdk.enabled && !parseHttpUrl(settings.forceSdk.url)) {
      setStatus("Enter a full http or https URL for the replacement SDK.", "err");
      setMode("redirect");
      return;
    }

    if (settings.localEdit.enabled && !settings.localEdit.edited) {
      setStatus(
        "Enable edited SDK injection only after an SDK is loaded.",
        "err"
      );
      setMode("edit");
      return;
    }

    if (settings.forceSdk.enabled && settings.localEdit.enabled) {
      // Older saved settings could have both on; Redirect is the one shown first.
      settings.localEdit.enabled = false;
    }

    updatedAt = updatedAt || Date.now();
    settings.localEdit.updatedAt = updatedAt;

    const res = await sendMessage({ type: "MCP_SAVE_SETTINGS", settings });
    if (!res.ok) {
      setStatus(res.error || "Failed to save settings", "err");
      return;
    }

    applySettings(res.settings);

    const where = describeSites(res.settings.sites);
    const f = res.settings.forceSdk.fetched;
    if (res.settings.forceSdk.enabled && f && f.error) {
      setStatus("Settings saved, but fetching the replacement failed: " + f.error, "err");
      return;
    }
    if (res.settings.forceSdk.enabled) {
      setStatus("Settings saved. Redirect is on for " + where + ". Reload those pages.", "ok");
    } else if (res.settings.localEdit.enabled) {
      setStatus(
        "Settings saved. The edited SDK (id " +
          sdkFingerprint(res.settings.localEdit.edited) +
          ") runs on " + where + ". Reload those pages; the console shows the id that ran.",
        "ok"
      );
    } else {
      setStatus(
        "Settings saved. Both tools are off; every site loads the SDK normally.",
        "ok"
      );
    }
  }

  async function loadFromUrl() {
    const url = els.sdkSourceUrl.value.trim();
    if (!parseHttpUrl(url)) {
      setStatus("Enter a full http or https URL.", "err");
      return;
    }
    setStatus("Loading SDK...");
    const res = await sendMessage({ type: "MCP_FETCH_SDK", url });
    if (!res.ok) {
      setStatus(res.error || "Failed to fetch SDK", "err");
      return;
    }
    originalText = res.text || "";
    els.sdkEditor.value = originalText;
    loadedFileName = res.fileName || "sdk.js";
    loadedSourceUrl = url;
    updatedAt = Date.now();
    els.diffPanel.classList.remove("visible");
    updateEditChrome();
    updateDirtyBadge();
    setStatus("Loaded SDK from URL.", "ok");
  }

  function loadFromFile(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      originalText = String(reader.result || "");
      els.sdkEditor.value = originalText;
      loadedFileName = file.name || "sdk.js";
      loadedSourceUrl = "";
      updatedAt = Date.now();
      els.diffPanel.classList.remove("visible");
      updateEditChrome();
      updateDirtyBadge();
      setStatus("Loaded SDK from file.", "ok");
    };
    reader.onerror = () => setStatus("Failed to read file", "err");
    reader.readAsText(file);
  }

  function downloadEdited() {
    const text = els.sdkEditor.value;
    if (!text) {
      setStatus("Load an SDK before downloading.", "err");
      return;
    }
    const name =
      (loadedFileName || "sdk").replace(/\.js$/i, "") + "-edited.js";
    const blob = new Blob([text], { type: "application/javascript" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setStatus("Downloaded edited SDK.", "ok");
  }

  function buildLineDiff(aText, bText) {
    const a = aText.split("\n");
    const b = bText.split("\n");
    const n = a.length;
    const m = b.length;
    const dp = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
    for (let i = n - 1; i >= 0; i--) {
      for (let j = m - 1; j >= 0; j--) {
        if (a[i] === b[j]) dp[i][j] = dp[i + 1][j + 1] + 1;
        else dp[i][j] = Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
    const lines = [];
    let i = 0;
    let j = 0;
    let adds = 0;
    let dels = 0;
    while (i < n && j < m) {
      if (a[i] === b[j]) {
        lines.push({ type: "same", text: a[i], line: j + 1 });
        i++;
        j++;
      } else if (dp[i + 1][j] >= dp[i][j + 1]) {
        lines.push({ type: "del", text: a[i], line: i + 1 });
        dels++;
        i++;
      } else {
        lines.push({ type: "add", text: b[j], line: j + 1 });
        adds++;
        j++;
      }
    }
    while (i < n) {
      lines.push({ type: "del", text: a[i], line: i + 1 });
      dels++;
      i++;
    }
    while (j < m) {
      lines.push({ type: "add", text: b[j], line: j + 1 });
      adds++;
      j++;
    }
    return { lines, adds, dels };
  }

  function compareWithOriginal() {
    if (!originalText) {
      setStatus("Load an original SDK first to compare.", "err");
      return;
    }
    const edited = els.sdkEditor.value;
    if (edited === originalText) {
      els.diffPanel.classList.add("visible");
      els.diffBody.innerHTML =
        '<div class="st-diff-line same"><span class="ln"></span><span>No changes detected.</span></div>';
      els.diffStats.textContent = "0 added, 0 removed";
      setStatus("No changes detected.", "ok");
      return;
    }

    const { lines, adds, dels } = buildLineDiff(originalText, edited);
    els.diffBody.innerHTML = lines
      .map((row) => {
        const prefix =
          row.type === "add" ? "+" : row.type === "del" ? "-" : " ";
        return `<div class="st-diff-line ${row.type}"><span class="ln">${
          row.line || ""
        }</span><span>${prefix} ${escapeHtml(row.text)}</span></div>`;
      })
      .join("");
    els.diffStats.textContent = adds + " added, " + dels + " removed";
    els.diffPanel.classList.add("visible");
    setStatus("Comparison updated.", "ok");
  }

  function resetToOriginal() {
    if (!originalText) {
      setStatus("No original loaded.", "err");
      return;
    }
    if (els.sdkEditor.value !== originalText) {
      const ok = window.confirm(
        "Reset editor to the original SDK? Your current edits will be lost."
      );
      if (!ok) return;
    }
    els.sdkEditor.value = originalText;
    updatedAt = Date.now();
    els.diffPanel.classList.remove("visible");
    updateEditChrome();
    setStatus("Editor reset to original SDK.", "ok");
  }

  function parseHttpUrl(value) {
    try {
      const parsed = new URL(String(value || "").trim());
      return parsed.protocol === "http:" || parsed.protocol === "https:"
        ? parsed
        : null;
    } catch (_) {
      return null;
    }
  }

  function describeSites(sites) {
    if (!sites || !sites.length) return "no sites";
    if (sites.includes("*")) return "every site";
    return sites.join(", ");
  }

  function updateForceUrlWarning() {
    const url = els.forceUrl.value.trim();
    const show = needsFetchedSdk(url);
    els.forceFetchRow.hidden = !show;
    if (!show) return;
    const parsed = parseHttpUrl(url);
    const f = lastFetched;
    let text;
    let isErr = false;
    if (!f || f.url !== parsed.toString()) {
      text = "The extension will fetch this http file when you save.";
    } else if (f.error) {
      text = "Fetch failed: " + f.error + " The SDK loads normally until a fetch works.";
      isErr = true;
    } else {
      text =
        "Fetched " +
        (f.bytes < 1024 ? f.bytes + " bytes" : (f.bytes / 1024).toFixed(1) + " KB") +
        " at " +
        new Date(f.at).toLocaleTimeString() +
        ". After changing the file, click Fetch again.";
    }
    els.forceFetchStatus.textContent = text;
    els.forceFetchStatus.classList.toggle("err", isErr);
    document.getElementById("BtnRefetch").disabled =
      !(f && f.url === parsed.toString() && els.forceEnabled.checked);
  }

  function addSite(hostname) {
    const sites = parseSiteList(els.sitesInput.value);
    if (siteMatches(sites, hostname)) return false;
    sites.push(hostname.replace(/^www\./, ""));
    els.sitesInput.value = parseSiteList(sites).join(", ");
    updateDirtyBadge();
    renderOpenTabHosts();
    return true;
  }

  async function getWebTabs() {
    try {
      const tabs = await chrome.tabs.query({});
      return tabs
        .filter((t) => /^https?:/i.test(t.url || ""))
        .sort((x, y) => (y.lastAccessed || 0) - (x.lastAccessed || 0));
    } catch (_) {
      return [];
    }
  }

  async function renderOpenTabHosts() {
    const listed = parseSiteList(els.sitesInput.value);
    const hosts = [];
    (await getWebTabs()).forEach((t) => {
      const host = new URL(t.url).hostname;
      if (!hosts.includes(host) && !siteMatches(listed, host)) hosts.push(host);
    });
    els.openTabHosts.hidden = !hosts.length;
    els.openTabHostList.innerHTML = hosts
      .slice(0, 12)
      .map(
        (h) =>
          '<button type="button" class="st-host-chip" data-host="' +
          escapeHtml(h) +
          '">' +
          escapeHtml(h) +
          "</button>"
      )
      .join("");
  }

  async function prefillOpenUrl() {
    if (els.openUrl.value.trim()) return;
    const tabs = await getWebTabs();
    if (tabs.length) els.openUrl.value = tabs[0].url;
  }

  async function stopTools() {
    const res = await sendMessage({ type: "MCP_STOP_SDK_TOOLS", reload: true });
    if (!res.ok) {
      setStatus(res.error || "Failed to stop", "err");
      return;
    }
    applySettings(res.settings);
    setStatus(
      "Stopped. Every site loads the SDK normally" +
        (res.reloaded ? "; reloaded " + res.reloaded + (res.reloaded === 1 ? " tab." : " tabs.") : "."),
      "ok"
    );
  }

  async function injectAndOpen() {
    if (!els.sdkEditor.value) {
      setStatus("Load an SDK before injecting.", "err");
      return;
    }
    const target = parseHttpUrl(els.openUrl.value);
    if (!target) {
      setStatus("Enter the full http or https URL of the page to open.", "err");
      els.openUrl.focus();
      return;
    }

    if (!confirmNoSyntaxErrors()) return;
    const added = addSite(target.hostname);
    updatedAt = Date.now();
    setMode("edit");
    const settings = collectSettings();
    settings.localEdit.updatedAt = updatedAt;

    const saved = await sendMessage({ type: "MCP_SAVE_SETTINGS", settings });
    if (!saved.ok) {
      setStatus(saved.error || "Failed to save before inject", "err");
      return;
    }
    applySettings(saved.settings);

    // The content script asks for the edited SDK at document_start, so a
    // fresh tab gets it before the page's own scripts run.
    await chrome.tabs.create({ url: target.toString() });
    setStatus(
      "Opened " +
        target.hostname +
        " with the edited SDK (id " +
        sdkFingerprint(saved.settings.localEdit.edited) +
        "; the page's console shows it)." +
        (added ? " Added " + target.hostname.replace(/^www\./, "") + " to Sites." : ""),
      "ok"
    );
  }

  async function init() {
    els.modeButtons.forEach((btn) =>
      btn.addEventListener("click", () => setMode(btn.dataset.mode))
    );

    document.getElementById("BtnStop").addEventListener("click", () => {
      stopTools().catch((e) => setStatus(String(e.message || e), "err"));
    });
    document.getElementById("BtnSaveAll").addEventListener("click", () => {
      saveSettings().catch((e) => setStatus(String(e.message || e), "err"));
    });
    document.getElementById("BtnLoadSdk").addEventListener("click", () => {
      loadFromUrl().catch((e) => setStatus(String(e.message || e), "err"));
    });
    document.getElementById("BtnLoadFile").addEventListener("click", () => {
      els.fileInput.click();
    });
    els.fileInput.addEventListener("change", () => {
      const file = els.fileInput.files && els.fileInput.files[0];
      loadFromFile(file);
      els.fileInput.value = "";
    });
    document
      .getElementById("BtnResetEdited")
      .addEventListener("click", resetToOriginal);
    document
      .getElementById("BtnDownloadEdited")
      .addEventListener("click", downloadEdited);
    document
      .getElementById("BtnCompare")
      .addEventListener("click", compareWithOriginal);
    document.getElementById("BtnHideDiff").addEventListener("click", () => {
      els.diffPanel.classList.remove("visible");
    });
    document.getElementById("BtnRefetch").addEventListener("click", async () => {
      setStatus("Fetching...");
      try {
        const res = await sendMessage({ type: "MCP_REFETCH_SDK" });
        if (!res.ok) throw new Error(res.error || "Fetch failed");
        applySettings(res.settings);
        const f = res.settings.forceSdk.fetched;
        if (f && f.error) setStatus("Fetch failed: " + f.error, "err");
        else setStatus("Fetched the replacement again. Reload the site with the cache off.", "ok");
      } catch (e) {
        setStatus(String(e.message || e), "err");
      }
    });
    document.getElementById("BtnInjectOpen").addEventListener("click", () => {
      injectAndOpen().catch((e) => setStatus(String(e.message || e), "err"));
    });
    els.openTabHostList.addEventListener("click", (e) => {
      const chip = e.target.closest("[data-host]");
      if (chip) addSite(chip.getAttribute("data-host"));
    });
    els.sitesInput.addEventListener("input", () => {
      updateDirtyBadge();
      renderOpenTabHosts();
    });
    els.openUrl.addEventListener("input", updateDirtyBadge);
    els.injectWhenMissing.addEventListener("change", updateDirtyBadge);
    els.forceUrl.addEventListener("input", updateForceUrlWarning);
    ["change", "input"].forEach((evt) => {
      els.forceUrl.addEventListener(evt, updateDirtyBadge);
      els.sdkSourceUrl.addEventListener(evt, updateDirtyBadge);
    });

    els.sdkEditor.addEventListener("input", () => {
      updateEditChrome();
    });
    els.sdkEditor.addEventListener("errors", renderSyntaxErrors);
    els.metaErrors.addEventListener("click", () => {
      const first = els.sdkEditor.errors()[0];
      if (first) els.sdkEditor.gotoLine(first.line, first.column);
    });
    const wrap = document.getElementById("editorWrap");
    if (els.sdkEditor.setWrap) {
      wrap.addEventListener("change", () => els.sdkEditor.setWrap(wrap.checked));
    } else {
      wrap.parentElement.hidden = true;
    }

    try {
      const res = await sendMessage({ type: "MCP_GET_SETTINGS" });
      if (res.ok) applySettings(res.settings);
      setMode(res.ok ? modeOf(mergeSettings(res.settings)) : "off");
      renderOpenTabHosts();
      prefillOpenUrl();
      if (res.settings?.localEdit?.edited) {
        setStatus("Draft restored from saved settings.", "ok");
      } else {
        setStatus("Ready.", "ok");
      }
    } catch (e) {
      setStatus(String(e.message || e), "err");
    }
  }

  init();
})();
